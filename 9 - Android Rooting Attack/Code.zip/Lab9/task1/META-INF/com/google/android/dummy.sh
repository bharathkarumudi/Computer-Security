echo "hello" > /system/dummy
